package pe.edu.pucp.lagstore.gestionusuarios.dao;
import pe.edu.pucp.lagstore.DAO.ICrud;
import pe.edu.pucp.lagstore.gestusuarios.model.Desarrollador;

public interface DesarrolladorDAO extends ICrud<Desarrollador>{

}

package pe.edu.pucp.lagstore.gestionusuarios.dao;
import pe.edu.pucp.lagstore.DAO.ICrud;
import pe.edu.pucp.lagstore.gestusuarios.model.Jugador;


public interface JugadorDAO extends ICrud<Jugador>{

}

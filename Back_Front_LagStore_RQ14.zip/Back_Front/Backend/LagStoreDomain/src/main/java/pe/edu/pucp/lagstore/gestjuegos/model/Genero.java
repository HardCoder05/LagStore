/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package pe.edu.pucp.lagstore.gestjuegos.model;

/**
 *
 * @author rio88
 */

public enum Genero {
    Accion, Rol, Estrategia, 
    Shooter, Simulación, Deportes, 
    Carreras;
}

package pe.edu.pucp.lagstore.gestusuarios.model;

public enum Rol {
    JUGADOR,
    ADMINISTRADOR,
    DESARROLLADOR,
}

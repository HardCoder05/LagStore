package pe.edu.pucp.lagstore.gestjuegos.model;

public enum ModeloNegocio {
    Free_to_play, Paga, 
    Suscripcion;
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package pe.edu.pucp.lagstore.gestusuario.services;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.util.ArrayList;
import pe.edu.pucp.lagstore.gestusuarios.model.Administrador;
import pe.edu.pucp.lagstore.gestusuarios.model.AdministradorBO;

/**
 *
 * @author Luis Rios
 */
@WebService(serviceName = "AdministradorWS")
public class AdministradorWS {
    private AdministradorBO boAdministrador;

//    @WebMethod(operationName = "insertarAdministrador")
//    public int insertarAdministrador(@WebParam(name = "administrador") Administrador administrador) {
//        boAdministrador=new AdministradorBO();
//        return boAdministrador.insertar(administrador);
//    }
    
//    @WebMethod(operationName = "modificarAdministrador")
//    public int modificarAdministrador(@WebParam(name = "administrador") Administrador administrador) {
//        boAdministrador=new AdministradorBO();
//        return boAdministrador.modificar(administrador);
//    }
    
//    @WebMethod(operationName = "eliminarAdministrador")
//    public int eliminarAdministrador(@WebParam(name = "idAdministrador") int idAdministrador) {
//        boAdministrador=new AdministradorBO();
//        return boAdministrador.eliminar(idAdministrador);
//    }
    
    @WebMethod(operationName = "listarTodosAdministradores")
    public ArrayList<Administrador> listarTodosAdministradores() {
        boAdministrador=new AdministradorBO();
        ArrayList<Administrador>administradores = boAdministrador.listarAdministradores();
        for(Administrador a : administradores){
            System.out.println(a);
        }
        return boAdministrador.listarAdministradores();
    }
    
//    @WebMethod(operationName = "obtenerAdministradorPorID")
//    public Administrador obtenerAdministradorPorID(@WebParam(name = "idAdministrador")int idAdministrador) {
//        boAdministrador=new AdministradorBO();
//        return boAdministrador.obtenerPorId(idAdministrador);
//    }
    
    
    
}

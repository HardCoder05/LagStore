/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.pucp.lagstore.gestionjuegos.dao;


import pe.edu.pucp.lagstore.DAO.ICrud;
import pe.edu.pucp.lagstore.gestjuegos.model.Juego;

/**
 *
 * @author Luis Rios
 */
public interface JuegoDAO extends ICrud<Juego> {
    
}

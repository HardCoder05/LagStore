package pe.edu.pucp.lagstore.gestionjuegos.dao;

import pe.edu.pucp.lagstore.DAO.ICrud;
import pe.edu.pucp.lagstore.gestjuegos.model.Biblioteca;


public interface BibliotecaDAO extends ICrud<Biblioteca> {
    
}

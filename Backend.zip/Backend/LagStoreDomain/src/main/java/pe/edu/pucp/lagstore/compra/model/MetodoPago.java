package pe.edu.pucp.lagstore.compra.model;

public enum MetodoPago {
    Visa,
    Mastercard,
    PagoEfectivo,
    PayValido;
}